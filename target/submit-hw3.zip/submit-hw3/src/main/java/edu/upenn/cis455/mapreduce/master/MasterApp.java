package edu.upenn.cis455.mapreduce.master;

import static spark.Spark.*;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import edu.upenn.cis.stormlite.tuple.Fields;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import edu.upenn.cis.stormlite.Config;
import edu.upenn.cis.stormlite.Topology;
import edu.upenn.cis.stormlite.TopologyBuilder;
import edu.upenn.cis.stormlite.bolt.MapBolt;
import edu.upenn.cis.stormlite.bolt.PrintBoltHelper;
import edu.upenn.cis.stormlite.bolt.ReduceBolt;
import edu.upenn.cis.stormlite.distributed.WorkerHelper;
import edu.upenn.cis.stormlite.distributed.WorkerJob;
import edu.upenn.cis.stormlite.spout.FileSpout;
import edu.upenn.cis.stormlite.spout.FileSpoutHelper;
import edu.upenn.cis.stormlite.spout.FileSpoutImplementation;
import edu.upenn.cis455.mapreduce.worker.WorkWrapper;
import edu.upenn.cis455.mapreduce.worker.WorkerServer;


class MasterApp {
	 
	static final Logger logger = LogManager.getLogger(MasterApp.class);
	private static Map<String,Map<String,String>> workers = new HashMap<>();
	private static Map<String,Long> lastAccessTime = new HashMap<>();
	private static String masterWorker;
	private static Map<Integer,String> workerIdMap = new HashMap<>();
	static final int portNum = 8000;
	  
	
	private static final String WORD_SPOUT = "WORD_SPOUT";
	private static final String MAP_BOLT = "MAP_BOLT";
	private static final String REDUCE_BOLT = "REDUCE_BOLT";
	private static final String PRINT_BOLT = "PRINT_BOLT";
	
	 public static void registerAndLaunchPage(){
		 get("/status", (request,response) -> {
		    	StringBuilder sb = new StringBuilder();
		        sb.append("<html><head><title>Master Status</title></head>\n");
		        sb.append("<body><h1>Master Webpage</h1>");

		        sb.append("<table><tr>");
		        sb.append("<th>IP Port</th>");
		        sb.append("<th>Status</th>");
		        sb.append("<th>Job</th>");
		        sb.append("<th>Keys Read</th>");
		        sb.append("<th>Keys Written</th>");
		        //TODO: checck if results are necessary 
		        //sb.append("<th>Results</th></tr>");
		        
		        for(String worker : workers.keySet()){
		            if(System.currentTimeMillis() < lastAccessTime.get(worker) + 30*1000){
		                Map<String,String> workerStatus = workers.get(worker); 
		                sb.append("<tr><th>" + worker + "</th>");
		                sb.append("<th>" + workerStatus.get("status") + "</th>");
		                sb.append("<th>" + workerStatus.get("job") + "</th>");
		                sb.append("<th>" + workerStatus.get("keysRead") + "</th>");
		                sb.append("<th>" + workerStatus.get("keysWritten") + "</th><");
		             
		            } 
		            else{
		                //System.out.println(worker + "------ : is time out");
		                workers.remove(worker);
		                lastAccessTime.remove(worker);
		            }
		        }
		        sb.append("</table>");
		        
		        sb.append("<h2>Web Form for Submitting Jobs</h2>");
		    	sb.append("<form method = \"POST\" name =\"statusform\" action = \"/status\" ><br/>");
		    	sb.append("The Class name of Job: <input type = \"text\" value = \"edu.upenn.cis455.mapreduce.job.MyJob\" name = \"job\"/><br/>");
		    	sb.append("The Input Directory: <input type = \"text\"  value = \"\" name = \"input\"/><br/>");
		    	sb.append("The Output Directory: <input type = \"text\"  value = \"\" name = \"output\"/><br/>");
		    	sb.append("The Number of Map Threads (MapBolt executors): <input type = \"text\" value = \"\" name = \"numMap\"/><br/>");
		    	sb.append("The Number of Reduce Threads (ReduceBolt executors): <input type = \"text\" value = \"\" name = \"numReduce\"/><br/>");
		    	sb.append("<input type = \"submit\" value = \"Submit\"/></form>");
		        
		        sb.append("</body></html>");

		        response.type("text/html");
		        
		        return sb.toString();
		    });
			get("/shutdown", (request, response) -> {
			    for(String workAddress : workers.keySet()){
			        if(workAddress.equals(masterWorker)){
	                    continue;
	                }
	        		sendThisJob("http://"+ workAddress, "GET", null, "shutdown", "");
	        	}
	        	System.exit(0);
			    return "shutdown";
		    });
	 }
		 
		 public static void WorkerStatusUpdates(){
			 get("/workerstatus", (request,response) -> {
			      /* do something with the information in the request */
			    	  String workerIp = request.ip();
			          String port = request.queryParams("port");
			          String workerId = workerIp + ":" + port;
			          Map<String,String> workerStatus = new HashMap<String,String>();
			          workerStatus.put("status",request.queryParams("status"));
			          workerStatus.put("job",request.queryParams("job"));
			          workerStatus.put("keysRead",request.queryParams("read"));
			          workerStatus.put("keysWritten",request.queryParams("written"));
			          
			          //TODO: for debugging purpose only, comment out afterward
//			          System.out.println("port num check:" + port +"; status check:" + request.queryParams("status"));
//			          System.out.println("port num check:" + port +"; job check:" + request.queryParams("job"));
//			          System.out.println("port num check:" + port +"; keysRead:" + request.queryParams("read"));
//			          System.out.println("port num check: " + port +"; keysWritten:" + request.queryParams("written"));
//			          
			          
			          workers.put(workerId,workerStatus);
			          lastAccessTime.put(workerId,System.currentTimeMillis());
			          
			          return "";
			    });
			  }
		  public static void LaunchJobViaMaster(Config config){
			  logger.info("************ Creating the job request ***************");
				
		        //FileSpout spout = new FileSpoutHelper();
		        FileSpoutImplementation spout = new FileSpoutImplementation();
		        MapBolt mapBolt = new MapBolt();
		        ReduceBolt reduceBolt = new ReduceBolt();
		        PrintBoltHelper printerBolt = new PrintBoltHelper();
		        
		        TopologyBuilder tbBuilder = new TopologyBuilder();
		        
		        // Only one source ("spout") for the words
		        tbBuilder.setSpout(WORD_SPOUT, spout, Integer.valueOf(config.get("spoutExecutors")));
			        
		        // Parallel mappers, each of which gets specific words
		        tbBuilder.setBolt(MAP_BOLT, mapBolt, Integer.valueOf(config.get("mapExecutors"))).fieldsGrouping(WORD_SPOUT, new Fields("value"));
		        
		        // Parallel reducers, each of which gets specific words
		        tbBuilder.setBolt(REDUCE_BOLT, reduceBolt, Integer.valueOf(config.get("reduceExecutors"))).fieldsGrouping(MAP_BOLT, new Fields("key"));

		        // Only use the first printer bolt for reducing to a single point
		        tbBuilder.setBolt(PRINT_BOLT, printerBolt, 1).firstGrouping(REDUCE_BOLT);
		        
		        Topology topo = tbBuilder.createTopology();
		        
			    WorkerJob job = new WorkerJob(topo, config);
			    
			    ObjectMapper mapper = new ObjectMapper();
		        mapper.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
			        
			    try {
		            config.put("workerIndex", "0");            
		            WorkerServer.createWorker(config);
			        
					String[] workers = WorkerHelper.getWorkers(config);

					int i = 0;
					for (String dest: workers) {
					    if(dest==null){
					        System.out.println("The worker index is not successive !! Please input again!");
					    }
					    //System.out.println("[worker list]" + config.get("workerList"));
				        config.put("workerIndex", String.valueOf(i++));
						if (sendThisJob(dest, "POST", config, "definejob", 
								mapper.writerWithDefaultPrettyPrinter().writeValueAsString(job)).getResponseCode() != 
								HttpURLConnection.HTTP_OK) {
							throw new RuntimeException("definejob request failed");
						}
					}
					
					for (String dest: workers) {
						if (sendThisJob(dest, "POST", config, "runjob", "").getResponseCode() != 
								HttpURLConnection.HTTP_OK) {
							throw new RuntimeException("runjob request failed");
						}
					}
				} catch (JsonProcessingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
			        System.exit(0);
				} catch (IOException ioe){
			        ioe.printStackTrace();
			        System.exit(0);
			    }
		  }
		 
		  public static HttpURLConnection sendThisJob(String destination, String requestType, Config config, String job, String infoToSend) throws IOException {
		    	URL url = new URL(destination + "/" + job);
		    	System.out.println("Sending request to this url: " + url.toString());
		    	
		    	logger.info("Sending request to this url: " + url.toString());

		    	HttpURLConnection httpConn = (HttpURLConnection)url.openConnection();
		    	httpConn.setDoOutput(true);
		    	httpConn.setRequestMethod(requestType);
		    	
		    	if (requestType.equals("POST")) {
		    		httpConn.setRequestProperty("Content-Type", "application/json");
		    		OutputStream os = httpConn.getOutputStream();
		    		byte[] thingstoSend = infoToSend.getBytes();
		    		os.write(thingstoSend);
		    		os.flush();
		    	} else
		    	httpConn.getOutputStream();
		    	//System.out.println("http connection: "+httpConn.getResponseCode());
		    	return httpConn;
		    }
		  
		    public static void respondByWorker(Config config){
		        get("/workermaster",(request,response)->{
		            String ip = request.ip();
		            String portStr = request.queryParams("port");
		            String indexStr = request.queryParams("index");
		            String ipString = ip + ":" + portStr;
		            //System.out.println("Get ip " + ipString + " and port " + port + "and index " + index);
		            workerIdMap.put(Integer.valueOf(indexStr),ipString);
		            synchronized(config){
		                String workerliststring = "";
		        		// Wait for the worker to respond
		        		for(int i = 0; i < workerIdMap.size() ;i++){
		        		    if(i!=0){
		        		        workerliststring+=",";
		        		    }
		        		    workerliststring += workerIdMap.get(i);
		        		}
		        		config.put("workerList: ", "{" + workerliststring + "}");
		                return "";   
		            }
		        });
		    }
		  public static void registerRunJob(Config config){
		        post("/status",(request,response)->{
		            //System.out.println("-----------new job started----------");
		            String jobName = request.queryParams("job");
		            String numOfMaps = request.queryParams("numMap");
		            String numOfReduce =  request.queryParams("numReduce");
		            String inputDir = request.queryParams("input");
		            String outputDir = request.queryParams("output");
		            
		            //System.out.println("{RunJob} jobName: " + jobName);
		            //System.out.println("{RunJob} mapperNum: " + numOfMaps);
		            //System.out.println("{RunJob} reducerNum: " + numOfReduce);
		            //logger.info("------{RunJob} inputDir-----: " + inputDir);
		            //System.out.println("{RunJob} outputDir: " + outputDir);
		            
		            config.put("job", jobName); 
		            config.put("mapClass", jobName);
		            config.put("jobClass", jobName);
		            config.put("reduceClass", jobName);
		            config.put("spoutExecutors", "1");
		            config.put("mapExecutors", numOfMaps);
		            config.put("reduceExecutors", numOfReduce);
		            config.put("inputDir", inputDir);
		            config.put("outputDir", outputDir);
		            
		            LaunchJobViaMaster(config);
		            WorkWrapper workerReporter = new WorkWrapper(portNum, config.get("master"));
				    workerReporter.start();
				    response.type("text/html");
				    response.redirect("/status");
		            return "";   
		        });
		    }
		 
		 
	 
	
	
  public static void main(String args[]) {

	  port(portNum);

    /* Just in case someone opens the root URL, without /status... */

    get("/", (request,response) -> {
      return "Please go to the <a href=\"/status\">status page</a>!";
    });
    
    Config config = new Config();

    config.put("master", "127.0.0.1:8000"); 
    //config.put("jobClass", "edu.upenn.cis455.mapreduce.job.MyJob");
    config.put("spoutExecutors", "1");

	masterWorker = config.get("master");
	
	config.put("workerList", "{" + config.get("master") + "}");
	
	// If we're the Master, we need to initiate the computation
	workerIdMap.put(0,config.get("master"));
	respondByWorker(config);
	
    // Let the server start up
	logger.info("************ Creating the job request ***************");

	
	registerRunJob(config);
	WorkerStatusUpdates();
	registerAndLaunchPage();
	//System.out.println("Master has been set up");
	WorkWrapper workerReporter = new WorkWrapper(portNum, config.get("master"));
    workerReporter.start();
    
    
  }
    

    
}